/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ir;

import utils.IRVisitor;

/**
 *
 * @author beh01
 */
public class BinaryExpression extends Expression   {
    private String operator;
    private Expression left, right;

    public BinaryExpression(String operator, Expression left, Expression right) {
        this.operator = operator;
        this.left = left;
        this.right = right;
    }

    public Expression getLeft() {
        return left;
    }

    public String getOperator() {
        return operator;
    }

    public Expression getRight() {
        return right;
    }

    @Override
    public void accept(IRVisitor visitor) {
        left.accept(visitor);
        visitor.visit(this);
    }

    @Override
    public String toString() {
        return left.toString()+operator+right.toString();
    }

}
