/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ir;

import utils.IRVisitor;

/**
 *
 * @author beh01
 */
public class UnaryExpression extends Expression     {
    private String operator;
    private Expression expression;

    public UnaryExpression(String operator, Expression expression) {
        this.operator = operator;
        this.expression = expression;
    }

    public Expression getExpression() {
        return expression;
    }

    public String getOperator() {
        return operator;
    }

    @Override
    public void accept(IRVisitor visitor) {
        expression.accept(visitor);
        visitor.visit(this);
    }

    @Override
    public String toString() {
        return operator+expression.toString();
    }
}
