/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ir;

import utils.IRVisitor;

/**
 *
 * @author beh01
 */
public class ConditionalExpression extends Expression {
    Expression condition;
    Expression left, right;

    public ConditionalExpression(Expression condition, Expression left, Expression right) {
        this.condition = condition;
        this.left = left;
        this.right = right;
    }

    public Expression getCondition() {
        return condition;
    }

    public Expression getLeft() {
        return left;
    }

    public Expression getRight() {
        return right;
    }

    @Override
    public void accept(IRVisitor visitor) {
        condition.accept(visitor);
        left.accept(visitor);
        right.accept(visitor);

        visitor.visit(this);
    }

    @Override
    public String toString() {
        return "("+condition.toString()+")?"+left.toString()+":"+right.toString();
    }

}
