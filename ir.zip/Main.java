
import ir.BlockStatement;
import utils.TypeChecking;
import utils.Error;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author beh01
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Error.clearErrors();
        TypeChecking t = new TypeChecking();
        BlockStatement program = new BlockStatement();
        System.out.println(program.toString());
        program.accept(t);
        if (Error.noErrors()) {
            System.out.println("Program is correct.");
        }else {
            Error.printErrors();
        }
    }

}
