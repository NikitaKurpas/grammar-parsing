/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author beh01
 */
public class Error {
    private int line, column;
    private String message;

    public Error(int line, int column, String message) {
        this.line = line;
        this.column = column;
        this.message = message;
    }

    @Override
    public String toString() {
        return "Error: "+line+", "+column+" - "+message;
    }
    private static List<Error> errors = new ArrayList<Error>();
    public static void clearErrors() {
        errors.clear();
    }
    public static void addError(Error e) {
        errors.add(e);
    }
    public static boolean noErrors() {
        return errors.isEmpty();
    }
    public static void printErrors() {
        for(Error e : errors) {
            System.err.println(e);
        }
    }
}
