/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package utils;

import utils.IRVisitor;
import ir.AssigmentStatement;
import ir.BinaryExpression;
import ir.BlockStatement;
import ir.ConditionalExpression;
import ir.IfStatement;
import ir.Literal;
import ir.PrintStatement;
import ir.ReadStatement;
import ir.UnaryExpression;
import ir.Variable;
import ir.WhileStatement;

/**
 *
 * @author beh01
 */
public class TypeChecking implements IRVisitor{

    public void visit(AssigmentStatement st) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(BinaryExpression exp) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(BlockStatement st) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(ConditionalExpression exp) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(IfStatement st) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(Literal exp) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(PrintStatement st) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(ReadStatement st) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(UnaryExpression exp) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(Variable exp) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void visit(WhileStatement st) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
